#ifndef __DHT11_H__
#define __DHT11_H__

#include "main.h"

#define u8 unsigned char 
#define u16 unsigned short 
#define u32 unsigned int


//�������Ŷ���
#define DATA_SET() 		HAL_GPIO_WritePin(DATA_GPIO_Port, DATA_Pin, GPIO_PIN_SET)
#define DATA_RESET()  HAL_GPIO_WritePin(DATA_GPIO_Port, DATA_Pin, GPIO_PIN_RESET)

#define DATA_READ()		HAL_GPIO_ReadPin(DATA_GPIO_Port, DATA_Pin)


#define DATA_Pin				GPIO_PIN_7
#define DATA_GPIO_Port	GPIOA


typedef struct
{
	u8 Data[5];
	u8 index;
	u8 temp;
	u8 humidity;
	
}DHT11_DATA;

extern DHT11_DATA DHT11_data;

void DHT11_Task(void);

#endif
